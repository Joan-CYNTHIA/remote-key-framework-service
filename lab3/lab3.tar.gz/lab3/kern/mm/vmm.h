#ifndef __KERN_MM_VMM_H__
#define __KERN_MM_VMM_H__

#include <defs.h>
#include <list.h>
#include <memlayout.h>
#include <sync.h>

//pre define
struct mm_struct;

// the virtual continuous memory area(vma)
struct vma_struct {
    // 指向一个比vma_struct更高的抽象层次的数据结构 mm_struct，关联上层内存管理器
    struct mm_struct *vm_mm;
    // vma 的开始地址
    uintptr_t vm_start;
    // vma 的结束地址
    uintptr_t vm_end;
    // 虚拟内存空间的属性
    uint32_t vm_flags;
    // 双向链表，按照从小到大的顺序把虚拟内存空间链接起来
    list_entry_t list_link;
};

#define le2vma(le, member)                  \
    to_struct((le), struct vma_struct, member)

#define VM_READ                 0x00000001 //只读
#define VM_WRITE                0x00000002 //可读写
#define VM_EXEC                 0x00000004 //可执行

// the control struct for a set of vma using the same PDT
struct mm_struct {
    // 双向链表头，链接了所有属于同一页目录表的虚拟内存空间
    list_entry_t mmap_list;
    //指向当前正在使用的虚拟内存空间
    struct vma_struct *mmap_cache;
    //指向mm_struct数据结构所维护的页表
    pde_t *pgdir;
    //记录mmap_list里面链接的vma_struct的个数
    int map_count;
    //指向用来链接记录访问情况的链表头
    void *sm_priv;
};

// struct mm_struct *mm:进程的用户空间
// uintptr_t addr:要查询的地址
struct vma_struct *find_vma(struct mm_struct *mm, uintptr_t addr);
struct vma_struct *vma_create(uintptr_t vm_start, uintptr_t vm_end, uint32_t vm_flags);
void insert_vma_struct(struct mm_struct *mm, struct vma_struct *vma);

struct mm_struct *mm_create(void);
void mm_destroy(struct mm_struct *mm);

void vmm_init(void);

//mm: 应用程序虚拟存储总管
//error_code:错误类型
//addr: 出错的地址
int do_pgfault(struct mm_struct *mm, uint32_t error_code, uintptr_t addr);

extern volatile unsigned int pgfault_num;
extern struct mm_struct *check_mm_struct;
#endif /* !__KERN_MM_VMM_H__ */

