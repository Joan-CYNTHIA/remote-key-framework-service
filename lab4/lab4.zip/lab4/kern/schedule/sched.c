#include <list.h>
#include <sync.h>
#include <proc.h>
#include <sched.h>
#include <assert.h>

void
wakeup_proc(struct proc_struct *proc) {
    assert(proc->state != PROC_ZOMBIE && proc->state != PROC_RUNNABLE);
    proc->state = PROC_RUNNABLE;
}

void
schedule(void) {
    // 定义中断变量
    bool intr_flag;
    //当前list，下一list
    list_entry_t *le, *last;
    // 下一进程，清除调度标志
    struct proc_struct *next = NULL;
    // 关闭中断
    local_intr_save(intr_flag);
    {
        // 令当前进程处于不用调度的状态
        current->need_resched = 0;
        // last是否是idle进程（第一个创建的进程），如果是，则从表头开始搜索，否则获取下一链表
        last = (current == idleproc) ? &proc_list : &(current->list_link);
        le = last;
        // 循环寻找可调度的进程
        do {
            if ((le = list_next(le)) != &proc_list) {
                // 获取下一进程
                next = le2proc(le, list_link);
                // 找到一个位于就绪状态的进程
                if (next->state == PROC_RUNNABLE) {
                    break;
                }
            }
        } while (le != last);
        // 如果没有找到，则next指回idleproc
        if (next == NULL || next->state != PROC_RUNNABLE) {
            next = idleproc;
        }
        // 找到需要调度的进程数加1
        next->runs ++;
        if (next != current) {
            proc_run(next);
        }
    }
    // 恢复中断
    local_intr_restore(intr_flag);
}

