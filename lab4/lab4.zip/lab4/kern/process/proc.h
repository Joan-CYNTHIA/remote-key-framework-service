#ifndef __KERN_PROCESS_PROC_H__
#define __KERN_PROCESS_PROC_H__

#include <defs.h>
#include <list.h>
#include <trap.h>
#include <memlayout.h>


// process's state in his life cycle
enum proc_state {
    // 未初始化的
    PROC_UNINIT = 0,  // uninitialized
    // 等待状态
    PROC_SLEEPING,    // sleeping
    // 就绪/运行状态
    PROC_RUNNABLE,    // runnable(maybe running)
    // 僵死状态
    PROC_ZOMBIE,      // almost dead, and wait parent proc to reclaim his resource
};

// Saved registers for kernel context switches.
// Don't need to save all the %fs etc. segment registers,
// because they are constant across kernel contexts.
// Save all the regular registers so we don't need to care
// which are caller save, but not the return register %eax.
// (Not saving %eax just simplifies the switching code.)
// The layout of context must match code in switch.S.

// 保存的上下文寄存器
struct context {
    uint32_t eip;
    uint32_t esp;
    uint32_t ebx;
    uint32_t ecx;
    uint32_t edx;
    uint32_t esi;
    uint32_t edi;
    uint32_t ebp;
};

#define PROC_NAME_LEN               15
#define MAX_PROCESS                 4096
#define MAX_PID                     (MAX_PROCESS * 2)

extern list_entry_t proc_list;

struct proc_struct {
     // 当前进程的状态
    enum proc_state state;                      // Process state
    // 进程 ID
    int pid;                                    // Process ID
    // 当前进程被调度的次数
    int runs;                                   // the running times of Proces
    // 内核栈
    uintptr_t kstack;                           // Process kernel stack
    // 是否需要被调度
    volatile bool need_resched;                 // bool value: need to be rescheduled to release CPU?
    // 父进程ID
    struct proc_struct *parent;                 // the parent process
    // 当前进程所管理的虚拟内存页，包括其所属的页目录项PDT
    struct mm_struct *mm;                       // Process's memory management field
    // 保存的上下文
    struct context context;                     // Switch here to run process
    // 中断所保存的上下文
    struct trapframe *tf;                       // Trap frame for current interrupt
    // 页目录表的地址
    uintptr_t cr3;                              // CR3 register: the base addr of Page Directroy Table(PDT)
    // 当前进程的相关标志
    uint32_t flags;                             // Process flag
    // 进程名称（可执行文件名）
    char name[PROC_NAME_LEN + 1];               // Process name
    // 用于连接list
    list_entry_t list_link;                     // Process link list 
    // 用于链接hash list
    list_entry_t hash_link;                     // Process hash list
};

#define le2proc(le, member)         \
    to_struct((le), struct proc_struct, member)

extern struct proc_struct *idleproc, *initproc, *current;

void proc_init(void);
void proc_run(struct proc_struct *proc);
int kernel_thread(int (*fn)(void *), void *arg, uint32_t clone_flags);

char *set_proc_name(struct proc_struct *proc, const char *name);
char *get_proc_name(struct proc_struct *proc);
void cpu_idle(void) __attribute__((noreturn));

struct proc_struct *find_proc(int pid);
int do_fork(uint32_t clone_flags, uintptr_t stack, struct trapframe *tf);
int do_exit(int error_code);

#endif /* !__KERN_PROCESS_PROC_H__ */

